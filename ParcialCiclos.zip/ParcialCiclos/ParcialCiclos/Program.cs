﻿using System;

namespace ParcialCiclos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int vehiculo;
            int tarifa;
            float horas;
            double resultado = 1;
            double final = 0;
            int moto =0;
            int carro=0;
            int camion = 0;
            for (int i = 1; i < 13; i++)
            {
                Console.WriteLine("Ingrese su tipo de vehiculo (Moto=1, Automóvil=2, Camion=3)");
                vehiculo = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese su cantidad de horas");
                horas = float.Parse(Console.ReadLine());
                if (vehiculo == 1)
                {
                    moto++;
                    tarifa = 3000;
                    resultado = tarifa * horas;
                    if (horas > 4)
                    {
                        resultado -= resultado * 0.10;
                    }
                }
                else if (vehiculo == 2)
                {
                    carro++;
                    tarifa = 5000;
                    resultado = tarifa * horas;
                    if (horas > 3)
                    {
                        tarifa = 20000;
                        resultado = tarifa ;
                    }
                }
                else if (vehiculo == 3)
                        {
                    camion++;
                    tarifa = 10000;
                    resultado = tarifa * horas;
                    
                    if (horas > 5) 
                    {
                        resultado = tarifa * horas + 15000;
                    }
                }
                Console.WriteLine("Valor a pagar: " + resultado);
                final += resultado;
            }
            Console.WriteLine("Reporte global: ");
            Console.WriteLine("Dinero recaudado: " + final);
            Console.WriteLine("Motos: " + moto);
            Console.WriteLine("Carros: " + carro);
            Console.WriteLine("Camiones: "+ camion);
        }
    }
}
